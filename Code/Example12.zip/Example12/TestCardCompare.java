import java.io.*; 
import java.util.Arrays; 

public class TestCardCompare
{
   public static void main(String[] args){
      CardCompare[] c = new CardCompare[10]; 
      
      for (int i=0; i<10; i++){
           int suit = (int) (Math.random()*4); 
           int rank = (int) (Math.random()*13)+1; 
           try {
            c[i] = new CardCompare(suit, rank); 
           } catch(IOException ex){
              ex.printStackTrace(); 
            }
        }
      
      System.out.print("\f"); 
      System.out.println(Arrays.asList(c)); 
      Arrays.sort(c);
      System.out.println(Arrays.asList(c)); 
    }
}

