import java.io.*; 
import java.util.Arrays; 
/**
 * Write a description of class GenericSearch here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GenericSearch
{
   public static<T extends Comparable> void printDeck(T[] data) {
        for (T card : data) {
              System.out.println(card);
        }
   }
   public static<T extends Comparable> int linearSearch(T[] data, T target) {
     for (int i = 0; i < data.length; i++) {
         if (data[i].equals(target)) {
             return i;
         }
     }
     return -1;
   }
   public static<T extends Comparable> int binarySearch(T[] data, T target) {
       int low = 0;
       int high = data.length - 1;
       while (low <= high) {
           int mid = (low + high) / 2;                 // step 1
           int comp = data[mid].compareTo(target); 

           if (comp == 0) {                            // step 2
               return mid;
            } else if (comp < 0) {                     // step 3
                low = mid + 1;
            } else {                                   // step 4
                high = mid - 1;
            }
        }
        return -1;
    }
   
   public static void main(String[] args){
      CardCompare[] c = new CardCompare[10]; 
      
      for (int i=0; i<10; i++){
           int suit = (int) (Math.random()*4); 
           int rank = (int) (Math.random()*13)+1; 
           try {
            c[i] = new CardCompare(suit, rank); 
           } catch(IOException ex){
              ex.printStackTrace(); 
            }
        }
      
      System.out.print("\f"); 
      System.out.println("Before Sorting-"+Arrays.asList(c)); 
      Arrays.sort(c);
      System.out.println("After  Sorting-"+Arrays.asList(c)); 
      System.out.println("printDeck():");
      printDeck(c);
      System.out.println(); 
      System.out.println("Searching Results ---"); 
      try{
          System.out.println(linearSearch(c, new CardCompare(2, 10))); 
          System.out.println(linearSearch(c, new CardCompare(0, 12)));
          System.out.println(linearSearch(c, new CardCompare(3, 2))); 
          System.out.println(linearSearch(c, new CardCompare(1, 5)));
          System.out.println(binarySearch(c, new CardCompare(2, 10))); 
          System.out.println(binarySearch(c, new CardCompare(0, 12)));
          System.out.println(binarySearch(c, new CardCompare(3, 2))); 
          System.out.println(binarySearch(c, new CardCompare(1, 5)));
          System.out.println(binarySearch(c, c[3]));
          System.out.println(binarySearch(c, c[7])); 
          System.out.println(binarySearch(c, c[0]));
      }
      catch (IOException ex){ ex.printStackTrace(); } 
    }
}
