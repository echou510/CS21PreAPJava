
/**
 * Write a description of class SerializedIndex here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SerializedIndex
{
   public final static String[] SUITS = {"clubs", "diamonds", "hearts", "spades"}; 
   public final static String[] RANKS = {null, "ace", "2", "3", "4", "5", "6", "7", 
                                         "8", "9", "10", "jack", "queen", "king"}; 
   public final static String[] suits = {"♣", "♦", "♥", "♠"};
   public final static String[] ranks = {null, "A", "2", "3", "4", "5", "6", "7", 
                                         "8", "9", "⒑", "J", "Q", "K"}; // ⒑ unicode U+2491	
   public final static String   ext = ".gif"; 
   public final static String   dir = "cards/"; 
   
   // get a card name
   public static String getName(int suit, int rank){
       String result = RANKS[rank]+SUITS[suit]; 
       return result; 
    }
   // get a card image file name
   public static String getFileName(int suit, int rank){
       String result = dir+RANKS[rank]+SUITS[suit]+ext; 
       return result; 
    }
   // get the symbol representation for a card
   public static String getSymbol(int suit, int rank){
       String result = suits[suit]+ranks[rank]; 
       return result; 
    }

   public static void main(String[] args){
      for (int i=0; i<52; i++){
           System.out.println(suits[i/13]+getName(i/13, i%13+1)+"   File Name="+getName(i/13, i%13+1)+ext); 
        }
    }
}
