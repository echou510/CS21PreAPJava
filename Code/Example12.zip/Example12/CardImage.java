import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 * Write a description of class CardImage here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CardImage{ 
  private int rank; 
  private int suit;
  public BufferedImage img;
  
  public CardImage(int suit, int rank){   
    this.rank = rank; 
    this.suit = suit;
    try {
      this.img = ImageIO.read(new File(SerializedIndex.getFileName(suit, rank)));
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  } 
  
  public String toLongString(){
       String s = SerializedIndex.RANKS[this.rank] + " of " +  SerializedIndex.SUITS[this.suit]; 
       return s; 
    }
  public String toString(){
       String result = SerializedIndex.suits[suit]+SerializedIndex.ranks[rank]; 
       return result; 
    }
}
