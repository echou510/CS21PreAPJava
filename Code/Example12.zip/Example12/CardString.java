
/**
 * Write a description of class CardString here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CardString
{
  private int rank; 
  private int suit; 
  public CardString(int suit, int rank) {   
    this.rank = rank; 
    this.suit = suit; 
  } 
  public String toLongString(){
       String s = SerializedIndex.RANKS[this.rank] + " of " +  SerializedIndex.SUITS[this.suit]; 
       return s; 
    }
  public String toString(){
       String result = SerializedIndex.suits[suit]+SerializedIndex.ranks[rank]; 
       return result; 
    }
    
  public static void main(String[] args){
       for (int i=0; i<52; i++){
           if (i%13 == 12) System.out.println(", "+(new CardString(i/13, i%13+1))); 
           else if (i%13==0)  System.out.print((new CardString(i/13, i%13+1))); 
           else System.out.print(", "+(new CardString(i/13, i%13+1))); 
        }
       for (int i=0; i<52; i++){
           System.out.println((new CardString(i/13, i%13+1)).toLongString()); 
        }
    }
}
