import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 * Write a description of class CardCompare here.
 *
 * @author (Eric Y. Chou)
 * @version (12/13/2017)
 */
public class CardCompare implements Comparable<CardCompare>
{
  // class section
  // Serialized Index for Cards
  public final static String[] SUITS = {"clubs", "diamonds", "hearts", "spades"}; 
  public final static String[] RANKS = {null, "ace", "2", "3", "4", "5", "6", "7", 
                                         "8", "9", "10", "jack", "queen", "king"}; 
  public final static String[] suits = {"♣", "♦", "♥", "♠"};
  public final static String[] ranks = {null, "A", "2", "3", "4", "5", "6", "7", 
                                         "8", "9", "⒑", "J", "Q", "K"}; // ⒑ unicode U+2491	
  public final static String   ext = ".gif"; 
  public final static String   dir = "cards/";   
  
  // get a card name
  public static String getName(int suit, int rank){
       String result = RANKS[rank]+SUITS[suit]; 
       return result; 
   }
  // get a card image file name
  public static String getFileName(int suit, int rank){
       String result = dir+RANKS[rank]+SUITS[suit]+ext; 
       return result; 
   }
  // get the symbol representation for a card
  public static String getSymbol(int suit, int rank){
       String result = suits[suit]+ranks[rank]; 
       return result; 
   }
  
  // instance section
  private final int rank; 
  private final int suit;
  private final BufferedImage img;
  
  public CardCompare(int suit, int rank) throws IOException {   
    this.rank = rank; 
    this.suit = suit;
    this.img = ImageIO.read(new File(getFileName(suit, rank)));
  } 
  
  public int getRank() { 
   return this.rank; 
  }  
  public int getSuit() { 
   return this.suit; 
  }
  public BufferedImage getImage() { 
   return this.img; 
  } 

  public String toLongString(){
       String s = RANKS[this.rank]+" of "+SUITS[this.suit]; 
       return s; 
    }
  public String toString(){
       String result = suits[suit]+ranks[rank]; 
       return result; 
    }
    
  public boolean equals(CardCompare that) { 
	return this.rank == that.rank &&
         this.suit == that.suit; 
  }
  
  @Override
  public int compareTo(CardCompare that) { 
    if (this.suit < that.suit) { return -1; } 
    if (this.suit > that.suit) { return 1;  } 
    if (this.rank < that.rank) { return -1; } 
    if (this.rank > that.rank) { return 1;  } 
    return 0; 
  }
}