
/**
 * Write a description of class Card here.
 *
 * @author (Eric Y. Chou)
 * @version (12/12/2017)
 */
public class Card0 { 
  private int rank; 
  private int suit; 
  public Card0(int suit, int rank) {   
    this.rank = rank; 
    this.suit = suit; 
  } 
}

