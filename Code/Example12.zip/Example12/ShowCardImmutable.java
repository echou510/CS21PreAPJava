import java.awt.Graphics;
import java.awt.Color; 
import javax.swing.JFrame;
import javax.swing.JPanel; 

// open image file for Canvas, JPanel
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.Dimension; 
/**
 * Write a description of class ShowCardImmutable here.
 *
 * @author (Eric Y. Chou)
 * @version (12/13/2017)
 */
public class ShowCardImmutable extends JPanel
{
    private CardImmutable card; 
    private BufferedImage img; 
    ShowCardImmutable(){  // setup data model 
        try {
        card = new CardImmutable(3, 3); 
        } catch (IOException ex){
        ex.printStackTrace();
        }
    }
    
    public void paint(Graphics g){ // set up view 
            img = card.getImage(); 
            super.paint(g);
            if (img != null) {
                int x = (getWidth() - img.getWidth()) / 2;
                int y = (getHeight() - img.getHeight()) / 2;
                g.drawImage(img, x, y, this);
            }
    }
    
    public static void main(String[] args) {  // controller
        int width=200, height=200; 
        JFrame frame = new JFrame("Show Immutable Cards");
        JPanel canvas = new ShowCardImmutable();
        canvas.setSize(width, height);
        canvas.setBackground(Color.gray); 
        frame.setPreferredSize(new Dimension(width, height));
        frame.setResizable(false);
        frame.add(canvas);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

