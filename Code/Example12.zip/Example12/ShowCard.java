import java.awt.Graphics;
import java.awt.Color; 
import javax.swing.JFrame;
import javax.swing.JPanel; 

// open image file for Canvas, JPanel
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.Dimension; 
/**
 * Write a description of class ShowCard here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ShowCard extends JPanel
{
    private BufferedImage img;
    ShowCard(){
            try {
                img = ImageIO.read(new File(SerializedIndex.getFileName(3, 3)));
            } catch (IOException ex) {
                ex.printStackTrace();
            }
    
    }
    
    public void paint(Graphics g) {
            super.paint(g);
            if (img != null) {
                int x = (getWidth() - img.getWidth()) / 2;
                int y = (getHeight() - img.getHeight()) / 2;
                g.drawImage(img, x, y, this);
            }
    }
    
    public static void main(String[] args) {
        int width=200, height=200; 
        JFrame frame = new JFrame("Show Cards");
        JPanel canvas = new ShowCard();
        canvas.setSize(width, height);
        canvas.setBackground(Color.gray); 
        frame.setPreferredSize(new Dimension(width, height));
        frame.setResizable(false);
        frame.add(canvas);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

