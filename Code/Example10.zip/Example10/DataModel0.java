import java.awt.Rectangle;
import java.awt.Point; 

/**
 * Write a description of class DataModel0 here.
 *
 * @author (Eric Y. Chou)
 * @version (12/11/2017)
 */
public class DataModel0
{
   public static void main(String[] args){
     Point p1 = new Point(3, 4); 
     Point p0 = new Point(0, 0); 
     Rectangle box = new Rectangle(0, 0, 100, 200); 
     System.out.println("Point 0: "+p0);
     System.out.println("Point 1: "+p1);
     System.out.println("Rectangle: "+box); 
    
    }
}

