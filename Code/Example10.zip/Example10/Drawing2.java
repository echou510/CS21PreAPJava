import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Color; 
import javax.swing.JFrame;

/**
 * Write a description of class Drawing2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Drawing2 extends Canvas
{
    public void paint(Graphics g) {
        g.setColor(Color.red);  // take red color to paint
        g.fillOval(100, 100, 200, 200);
        g.setColor(Color.blue); // take blue color to paint
        g.fillOval(150, 150, 200, 200);
    }
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("Set Color");
        Canvas canvas = new Drawing2();
        canvas.setSize(400, 400);
        canvas.setBackground(Color.lightGray); 
        frame.add(canvas);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
