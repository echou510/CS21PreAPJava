import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Rectangle; 
import java.awt.Color; 
import javax.swing.JFrame;
import javax.swing.JPanel; 
import java.lang.Thread; 
import java.awt.Dimension; 

/**
 * Write a description of class Drawing3B here.
 *
 * @author (Eric Y. Chou)
 * @version (12/11/2017)
 */
public class Drawing3B extends JPanel
{   // simulation setup
    static int y = 0; 
    static int x = 160;
    static int dx = 0; 
    static int dy = 5; 
    
    // data model
    static Rectangle r = new Rectangle(x, y, 40, 40); 
    static boolean b = true; 
    
    public static void moveRect(Rectangle box, int dx, int dy) throws Exception{
      box.x = box.x + dx;
      box.y = box.y + dy;
    }
    
    public void paint(Graphics g) {
        g.setColor(Color.black); 
        g.fillRect(0, 0, this.getWidth(), this.getHeight()); 
        g.setColor(Color.green);  // take green color to paint
        g.fillRect(r.x, r.y, r.width, r.height); 
    }
    
    public static void main(String[] args) {
        int width  = 400; 
        int height = 400; 
        
        JFrame frame = new JFrame("Moving");
        JPanel canvas = new Drawing3B();
        canvas.setSize(width, height);
        
        // Setup window
        canvas.setBackground(Color.black); 
        frame.setPreferredSize(new Dimension(width, height));
        frame.setResizable(false);
        frame.add(canvas);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        
        // operation control loop
        while (true){
         try {
             Thread.sleep(100); // sleep for 100 ticks (100 milli-secs)
             //canvas.repaint(); 
             if (r.y >= height || r.y <0) dy = -dy; 
             if (r.x >= width  || r.x <0) dx = -dx; 
             r.translate(dx, dy); 
             System.out.println(r); 
             canvas.repaint(); 
            }
         catch(Exception e){
            }
        }
    }
}
