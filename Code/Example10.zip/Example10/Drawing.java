import java.awt.Canvas;
import java.awt.Graphics;
import javax.swing.JFrame;
import java.awt.Color; 

/**
 * Write a description of class Drawing here.
 *
 * @author (Eric Y. Chou)
 * @version (12/11/2017)
 */
public class Drawing extends Canvas{
    
    public void paint(Graphics g) {
        g.fillOval(100, 100, 200, 200);
    }
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("My Drawing");
        Canvas canvas = new Drawing();
        canvas.setSize(400, 400);
        frame.add(canvas);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

