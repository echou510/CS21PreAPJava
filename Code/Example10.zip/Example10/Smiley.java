    import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Color; 
import javax.swing.JFrame;

/**
 * Write a description of class Smiley here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Smiley extends Canvas
{   static int width = 400, height=400; 
    static int cx=width/2, cy=height/2; 
    
    public void paint(Graphics g) {
        g.setColor(Color.yellow);  // take red color to paint
        g.fillOval(cx-100, cy-100, 200, 200);
        g.setColor(Color.white); // take blue color to paint
        g.fillOval(cx-75, cy-65, 60, 80);
        g.fillOval(cx+25, cy-75, 60, 80);
        g.setColor(Color.black); // take blue color to paint
        g.drawOval(cx-75, cy-65, 60, 80);
        g.drawOval(cx+25, cy-75, 60, 80);
        g.fillOval(cx-58, cy-29, 35, 35);
        g.fillOval(cx+41, cy-39, 35, 35);
        g.setColor(Color.white);
        g.fillOval(cx-23, cy+15, 70, 50); 
        g.setColor(Color.black); // take blue color to paint
        g.drawOval(cx-23, cy+15, 70, 50); 
    }
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("Set Color");
        Canvas canvas = new Smiley();
        canvas.setSize(width, height);
        canvas.setBackground(Color.black); 
        frame.add(canvas);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
