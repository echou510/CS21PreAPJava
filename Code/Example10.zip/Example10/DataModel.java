import java.awt.Rectangle;
import java.awt.Point; 

/**
 * Write a description of class DataModel here.
 *
 * @author (Eric Y. Chou)
 * @version (12/11/2017)
 */
public class DataModel
{
     public Point p1; 
     public Point p0;
     public Rectangle box; 
     
     DataModel(){
          p1 = new Point(3, 4); 
          p0 = new Point(0, 0); 
          box = new Rectangle(50, 50, 100, 200); 
        }
        
     public static void main(String[] args){
          DataModel d = new DataModel(); 
          System.out.println(d.p1); 
          System.out.println(d.p0);
          System.out.println(d.box); 
        }
}
