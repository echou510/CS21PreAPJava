import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Graphics2D; 
import java.awt.Color; 
import javax.swing.JFrame;

/**
 * Write a description of class MV0 here.
 *
 * @author (Eric Y. Chou)
 * @version (12/11/2017)
 */
public class MV0 extends Canvas
{    
    public void paint(Graphics g) {
        DataModel d = new DataModel();  // data model integrated here. 
        g.setColor(Color.red);  // take red color to paint
        g.fillRect(d.box.x, d.box.y, d.box.width, d.box.height); // solid box 
        //g.drawRect(250, 250, 100, 100);  // empty box
        g.setColor(Color.blue);
        g.drawLine(d.p0.x, d.p0.y, d.p1.x*100, d.p1.y*100); 
    }
    
    public static void main(String[] args){
        JFrame frame = new JFrame("Model View Integration");
        Canvas canvas = new MV0();
        canvas.setSize(400, 400);
        canvas.setBackground(Color.lightGray); 
        frame.add(canvas);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
