import java.io.File;
import java.io.IOException;

/**
 * Write a description of class Deck0 here.
 *
 * @author (Eric Y. Chou)
 * @version (12/13/2017)
 */
public class Deck0 { 
  private Card[] cards; 
  
  public Deck0() { 
    this.cards = new Card[52]; 
    int index = 0; 
    try{
      for (int suit = 0; suit <= 3; suit++) { 
        for (int rank = 1; rank <= 13; rank++) { 
          this.cards[index] = new Card(suit, rank); 
          index++; 
        } 
      } 
    } catch (IOException ex){ ex.printStackTrace(); }

  }

  public Deck0(int n) { 
    this.cards = new Card[n]; 
  } 
  
  public Card[] getCards() { 
    return this.cards; 
  } 
  
  public String toString(){
      String s="";
      s += "[";
      for (int i=0; i<this.cards.length; i++){
           if (i==0) s += cards[i].toString(); 
           else s += ", " + cards[i].toString(); 
        }
      s += "]";
      return s; 
    }
  
  public void shuffle() {
      for (int i=0; i<cards.length; i++) {
        // choose a random number between i and length - 1
        // swap the ith card and the randomly-chosen card
        int j = randomInt(0, cards.length-1);
        swapCards(i, j); 
      }
  }  
  private static int randomInt(int low, int high) {
    // return a random number between low and high
    return (int) (Math.random() * (high-low+1)) + low; 
  }

  private void swapCards(int i, int j) {
    // swap the ith and the jth cards in the array
    Card temp = cards[i]; 
    cards[i] = cards[j]; 
    cards[j] = temp; 
  }
  
  public static void main(String[] args){
     Deck0 d = new Deck0(); 
     System.out.println(d); 
  }
}