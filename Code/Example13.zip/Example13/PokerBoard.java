import java.io.File;
import java.io.IOException;

/**
 * Write a description of class PokerBoard here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PokerBoard
{
   final static int ROW = 4; 
   final static int COL = 13; 
   
   Card[][] cards;
   Deck0 d; 
   
   PokerBoard(){
      //try{
        d = new Deck0(); 
        cards = new Card[ROW][COL]; 
        Card[] deck = d.getCards(); 
        
        for (int i=0; i<52; i++){
            cards[i/13][i%13] = deck[i]; 
        }
      //} catch(IOException ex){ ex.printStackTrace(); }
    }
   public Card[][] getCards(){
       return cards; 
    }
   
   public void resetDeck(){
        d = new Deck0(); 
        Card[] deck = d.getCards();
        deck = d.getCards();
        for (int i=0; i<52; i++){
            cards[i/13][i%13] = deck[i]; 
        }
    }
   
   public void shuffleDeck(){
       for (int i=0; i<3; i++) d.shuffle(); 
       Card[] deck = d.getCards();
       deck = d.getCards();
       for (int i=0; i<52; i++){
            cards[i/13][i%13] = deck[i]; 
        }
    }
}
