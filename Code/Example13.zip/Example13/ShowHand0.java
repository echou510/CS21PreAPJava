import java.awt.Graphics;
import java.awt.Color; 
import javax.swing.JFrame;
import javax.swing.JPanel; 

// open image file for Canvas, JPanel
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.Dimension; 
import java.awt.Color; 

/**
 * Write a description of class ShowBoard here.
 *
 * @author (Eric Y. Chou)
 * @version (12/13/2017)
 */
public class ShowHand0 extends JPanel
{
    // Graphic View Parameters
    final static int row = 1; 
    final static int col = 5;
    final static int block_width = 80; 
    final static int block_height = 120;
    final static int zero_x = 3; 
    final static int zero_y = 11; 
    
    private PokerBoard b; 
    private BufferedImage img; 
    private Card[] hand = new Card[5]; 
    
    // Data Model Initialization
    ShowHand0() throws IOException {  // setup data model 
       for (int i=0; i<5; i++){
           int suit = (int)(Math.random()*4); 
           int rank = (int)(Math.random()*13)+1; 
           hand[i] = new Card(suit, rank); 
        }
       SelectionSortGeneric.selectionSort(hand); 
    }
    
    public void paint(Graphics g){ // set up view 
        super.paint(g);
        for (int i=0; i<row; i++){
          for (int j=0; j<col; j++){  
              img = hand[j].getImage(); 
              if (img != null) {
                  int x = zero_x + j * 80; 
                  int y = zero_y + i * 120; 
                  g.drawImage(img, x, y, this);
              }
           }
        }
    }
    
    public static void main(String[] args) {  // controller
        try{ 
          int width=col*block_width+10, height=row*block_height+25; 
          JFrame frame = new JFrame("Poker Board");
          JPanel canvas;
          canvas = new ShowHand0(); 
          canvas.setSize(width, height);
          Color color = new Color(60, 60, 60); 
          canvas.setBackground(color); 
          frame.setPreferredSize(new Dimension(width, height));
          frame.setResizable(false);
          frame.add(canvas);
          frame.pack();
          frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          frame.setVisible(true);
        }
        catch(IOException e) {}
        
    }
}

