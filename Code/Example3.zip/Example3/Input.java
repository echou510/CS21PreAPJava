/**
 * Examples from Chapter 3.
 */
public class Input {

    public static void main(String[] args) {
        System.out.println(System.out);

        System.out.print(4.0 / 3.0);
        System.out.printf("Four thirds = %.3f", 4.0 / 3.0);

        double pi = 3.14159;
        double x = (int) pi * 20.0;
    }

}
