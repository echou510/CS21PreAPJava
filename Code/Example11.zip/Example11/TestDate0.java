
/**
 * Write a description of class TestDate0 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestDate0
{
  public static void main(String[] args){
      Date0 d0 = new Date0(); 
    }
}
