
/**
 * Write a description of class Date7 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Date7
{
    private int year;
    private int month;
    private int day;

    public Date7() {
        this.year = 0;
        this.month = 0;
        this.day = 0;
    }

    public Date7(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }
    
    public int getYear() { 
        return this.year; 
    } 
    public int getMonth() { 
        return this.month; 
    }
    public int getDay() { 
        return this.day; 
    }
    public void setYear(int year) { 
        this.year = year; 
    }
    public void setMonth(int month) {
        this.month = month; 
    } 
    public void setDay(int Day) {
        this.day = day; 
    }
    public static void printDate(Date7 t) {
        System.out.printf("%04d/%02d/%02d\n", t.year, t.month, t.day); 
    }
    public String toString() { 
        return String.format("%04d/%02d/%02d", 
                        this.year, this.month, this.day); 
    }
    public boolean equals(Date7 that) { 
        return  this.year == that.year && 
                this.month == that.month && 
                this.day == that.day; 
    }
    public boolean equals(String str) { 
        return str.equals(this.toString()); 
    }
    public static void main(String[] args) {
        Date7 date = new Date7(2018, 1, 1); 
        Date7 date1 = new Date7(2018, 1, 1); 
        String s = date.toString();                
        System.out.println("date.toString()="+date); 
        printDate(date); 
        System.out.println(date.equals(date1));
        System.out.println(date.equals("1918/11/11"));
        System.out.println(date.equals("2018/01/01"));
        
    }
}
