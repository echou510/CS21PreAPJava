
/**
 * Write a description of class Time7 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Time7
{
    private int hour;
    private int minute;
    private double second;

    public Time7() {
        this.hour = 0;
        this.minute = 0;
        this.second = 0.0;
    }

    public Time7(int hour, int minute, double second) {
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }
    
    public int getHour() { 
        return this.hour; 
    } 
    public int getMinute() { 
        return this.minute; 
    }
    public double getSecond() { 
        return this.second; 
    }
    public void setHour(int hour) { 
        this.hour = hour; 
    }
    public void setMinute(int minute) {
        this.minute = minute; 
    } 
    public void setSecond(double second) {
        this.second = second; 
    }
    public static void printTime(Time7 t) {
        System.out.printf("%02d:%02d:%04.1f\n", t.hour, t.minute, t.second); 
    }
    public String toString() { 
        return String.format("%02d:%02d:%04.1f", 
                        this.hour, this.minute, this.second); 
    }
    public boolean equals(Time7 that) { 
        return  this.hour == that.hour && 
                this.minute == that.minute && 
                this.second == that.second; 
    }
    public boolean equals(String str) { 
        return str.equals(this.toString()); 
    }

    public static void main(String[] args) {
        Time7 time = new Time7(11, 59, 59.9); 
        Time7 time1 = new Time7(11, 59, 59.9); 
        String s = time.toString();
        System.out.println("time.toString()="+time); 
        printTime(time); 
        System.out.println(time.equals(time1));
        System.out.println(time.equals("09:30:00.0"));
        System.out.println(time.equals("11:59:59.9"));
    }

}
