
/**
 * Write a description of class Date0 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Date0
{
    private int year;
    private int month;
    private int day;

    public Date0() {
        this.year = 0;
        this.month = 0;
        this.day = 0;
    }

    public Date0(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }
}
