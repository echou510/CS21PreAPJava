
/**
 * Write a description of class Time8 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Time8
{
    private int hour;
    private int minute;
    private double second;

    public Time8() {
        this.hour = 0;
        this.minute = 0;
        this.second = 0.0;
    }

    public Time8(int hour, int minute, double second) {
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }
    
    public int getHour() { 
        return this.hour; 
    } 
    public int getMinute() { 
        return this.minute; 
    }
    public double getSecond() { 
        return this.second; 
    }
    public void setHour(int hour) { 
        this.hour = hour; 
    }
    public void setMinute(int minute) {
        this.minute = minute; 
    } 
    public void setSecond(double second) {
        this.second = second; 
    }
    public static void printTime(Time8 t) {
        System.out.printf("%02d:%02d:%04.1f\n", t.hour, t.minute, t.second); 
    }
    public String toString() { 
        return String.format("%02d:%02d:%04.1f", 
                        this.hour, this.minute, this.second); 
    }
    public boolean equals(Time8 that) { 
        return  this.hour == that.hour && 
                this.minute == that.minute && 
                this.second == that.second; 
    }
    public boolean equals(String str) { 
        return str.equals(this.toString()); 
    }

    /**
     * Adds two Times and returns a new Time object (static method).
     */
    public static Time8 add(Time8 t1, Time8 t2) {
        Time8 sum = new Time8();
        sum.hour = t1.hour + t2.hour;
        sum.minute = t1.minute + t2.minute;
        sum.second = t1.second + t2.second;
        
        return sum;
    }

    /**
     * Adds two Times and returns a new Time object (instance method).
     */
    public Time8 add(Time8 t2) {
        Time8 sum = new Time8();
        sum.hour = this.hour + t2.hour;
        sum.minute = this.minute + t2.minute;
        sum.second = this.second + t2.second;

        if (sum.second >= 60.0) {
            sum.second -= 60.0;
            sum.minute += 1;
        }
        if (sum.minute >= 60) {
            sum.minute -= 60;
            sum.hour += 1;
        }
        return sum;
    }

    /**
     * Adds the given number of seconds to this object (modifier).
     */
    public void increment(double seconds) {
        this.second += seconds;
        while (this.second >= 60.0) {
            this.second -= 60.0;
            this.minute += 1;
        }
        while (this.minute >= 60) {
            this.minute -= 60;
            this.hour += 1;
        }
    }
    
    public static void main(String[] args) {
        System.out.print("\f");
        Time8 time = new Time8(11, 59, 59.9); 
        Time8 time1 = new Time8(11, 59, 59.9); 
        String s = time.toString();
        System.out.println("time.toString()="+time); 
        printTime(time); 
        System.out.println(time.equals(time1));
        System.out.println(time.equals("09:30:00.0"));
        System.out.println(time.equals("11:59:59.9"));
        
        Time8 startTime = new Time8(18, 50, 0.0);
        System.out.println("Start Time="+startTime); 
        Time8 runningTime = new Time8(2, 16, 0.0);
        System.out.println("Running Time="+runningTime); 
        Time8 endTime = Time8.add(startTime, runningTime);
        System.out.println("End Time by Static="+endTime); 
        // using the instance method
        endTime = startTime.add(runningTime);
        System.out.println("End Time by Instance="+endTime); 
    }
}
