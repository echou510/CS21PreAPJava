
/**
 * Write a description of class Date4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Date4
{
    private int year;
    private int month;
    private int day;

    public Date4() {
        this.year = 0;
        this.month = 0;
        this.day = 0;
    }

    public Date4(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }
    
    public int getYear() { 
        return this.year; 
    } 
    public int getMonth() { 
        return this.month; 
    }
    public int getDay() { 
        return this.day; 
    }
    public void setYear(int year) { 
        this.year = year; 
    }
    public void setMonth(int month) {
        this.month = month; 
    } 
    public void setDay(int Day) {
        this.day = day; 
    }
}
