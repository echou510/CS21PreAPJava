
/**
 * Write a description of class Accumulator here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Accumulator{   
    Integer data; 
    Accumulator(Integer d){
       data = d; 
    }
    public Integer get(){
       return data; 
    }
    public void set(Integer i){
        this.data = i; 
    }
    public Integer accumulate(Integer other){
       this.data = this.data + (int) other; 
       return this.data; 
    }
    public Integer accumulate(Accumulator other){
       this.data = this.data + other.data; 
       return this.data; 
    }
    public String toString(){
      return data.toString(); 
    }
    
    public static void main(String[] args){
       Accumulator a = new Accumulator(3); 
       Accumulator b = new Accumulator(4); 
       System.out.println(a.accumulate(b)+" "+a); 
    }
}
