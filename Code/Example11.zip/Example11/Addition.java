
/**
 * Write a description of class Addition here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Addition{   
    Integer data; 
    Addition(Integer d){
       data = d; 
    }
    public Integer get(){
       return data; 
    }
    public void set(Integer i){
        this.data = i; 
    }
    public Integer add(Integer other){
       Integer result; 
       result = this.data + (int) other; 
       return result; 
    }
    public Integer add(Addition other){
       Integer result; 
       result = this.data + other.data; 
       return result; 
    }
    public String toString(){
      return data.toString(); 
    }
    
    public static void main(String[] args){
       Addition a = new Addition(3); 
       Addition b = new Addition(4); 
       System.out.println(a.add(b)+" "+a); 
    }
}
