
/**
 * Write a description of class Date6 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Date6
{
    private int year;
    private int month;
    private int day;

    public Date6() {
        this.year = 0;
        this.month = 0;
        this.day = 0;
    }

    public Date6(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }
    
    public int getYear() { 
        return this.year; 
    } 
    public int getMonth() { 
        return this.month; 
    }
    public int getDay() { 
        return this.day; 
    }
    public void setYear(int year) { 
        this.year = year; 
    }
    public void setMonth(int month) {
        this.month = month; 
    } 
    public void setDay(int Day) {
        this.day = day; 
    }
    public static void printDate(Date6 t) {
        System.out.printf("%04d/%02d/%02d\n", t.year, t.month, t.day); 
    }
    public String toString() { 
        return String.format("%04d/%02d/%02d", 
                        this.year, this.month, this.day); 
    }
    public static void main(String[] args) {
        Date6 date = new Date6(2018, 1, 1); 
        String s = date.toString();                
        System.out.println("date.toString()="+date); 
        printDate(date); 
    }
}
