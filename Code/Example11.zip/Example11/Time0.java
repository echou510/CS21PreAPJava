
/**
 * Write a description of class Time0 here.
 *
 * @author (Eric Y. Chou)
 * @version (12/12/2017)
 */
public class Time0 {
    private int hour;
    private int minute;
    private double second;

    public Time0() {
        this.hour = 0;
        this.minute = 0;
        this.second = 0.0;
    }

    public Time0(int hour, int minute, double second) {
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }
}
