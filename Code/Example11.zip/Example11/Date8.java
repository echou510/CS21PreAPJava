
/**
 * Write a description of class Date8 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Date8
{
    private int year;
    private int month;
    private int day;

    public Date8() {
        this.year = 0;
        this.month = 0;
        this.day = 0;
    }

    public Date8(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }
    
    public int getYear() { 
        return this.year; 
    } 
    public int getMonth() { 
        return this.month; 
    }
    public int getDay() { 
        return this.day; 
    }
    public void setYear(int year) { 
        this.year = year; 
    }
    public void setMonth(int month) {
        this.month = month; 
    } 
    public void setDay(int Day) {
        this.day = day; 
    }
    public static void printDate(Date8 t) {
        System.out.printf("%04d/%02d/%02d\n", t.year, t.month, t.day); 
    }
    public String toString() { 
        return String.format("%04d/%02d/%02d", 
                        this.year, this.month, this.day); 
    }
    public boolean equals(Date8 that) { 
        return  this.year == that.year && 
                this.month == that.month && 
                this.day == that.day; 
    }
    public boolean equals(String str) { 
        return str.equals(this.toString()); 
    }
     /**
     * Adds two Dates and returns a new Date object (static method).
     */
    public static Date8 add(Date8 t1, Date8 t2) {
        Date8 sum = new Date8();
        sum.year = t1.year + t2.year;
        sum.month = t1.month + t2.month;
        sum.day = t1.day + t2.day;
        
        if (sum.day >= 30) {
            sum.day -= 30;
            sum.month += 1;
        }
        if (sum.month >= 12) {
            sum.month -= 12;
            sum.year += 1;
        }
        return sum;
    }

    /**
     * Adds two Dates and returns a new Date object (instance method).
     */
    public Date8 add(Date8 t2) {
        Date8 sum = new Date8();
        sum.year = this.year + t2.year;
        sum.month = this.month + t2.month;
        sum.day = this.day + t2.day;

        if (sum.day >= 30) {
            sum.day -= 30;
            sum.month += 1;
        }
        if (sum.month >= 12) {
            sum.month -= 12;
            sum.year += 1;
        }
        return sum;
    }

    /**
     * Adds the given number of seconds to this object (modifier).
     */
    public void increment(int days) {
        this.day += days;
        while (this.day >= 30) {
            this.day -= 30;
            this.month += 1;
        }
        while (this.month >= 12) {
            this.month -= 12;
            this.year += 1;
        }
    }
       
    public static void main(String[] args) {
        Date8 date = new Date8(2018, 1, 1); 
        Date8 date1 = new Date8(2018, 1, 1); 
        String s = date.toString();                
        System.out.println("date.toString()="+date); 
        printDate(date); 
        System.out.println(date.equals(date1));
        System.out.println(date.equals("1918/11/11"));
        System.out.println(date.equals("2018/01/01"));
        
        Date8 startDate = new Date8(2018, 1, 1);
        System.out.println("Start Date="+startDate); 
        Date8 runningDate = new Date8(2, 1, 4);
        System.out.println("Running Date="+runningDate); 
        Date8 endDate = Date8.add(startDate, runningDate);
        System.out.println("End Date by Static="+endDate); 
        // using the instance method
        endDate = startDate.add(runningDate);
        System.out.println("End Date by Instance="+endDate);   
    }
}
