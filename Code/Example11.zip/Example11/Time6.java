
/**
 * Write a description of class Time6 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Time6
{
    private int hour;
    private int minute;
    private double second;

    public Time6() {
        this.hour = 0;
        this.minute = 0;
        this.second = 0.0;
    }

    public Time6(int hour, int minute, double second) {
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }
    
    public int getHour() { 
        return this.hour; 
    } 
    public int getMinute() { 
        return this.minute; 
    }
    public double getSecond() { 
        return this.second; 
    }
    public void setHour(int hour) { 
        this.hour = hour; 
    }
    public void setMinute(int minute) {
        this.minute = minute; 
    } 
    public void setSecond(double second) {
        this.second = second; 
    }
    public static void printTime(Time6 t) {
        System.out.printf("%02d:%02d:%04.1f\n", t.hour, t.minute, t.second); 
    }
    public String toString() { 
        return String.format("%02d:%02d:%04.1f", 
                        this.hour, this.minute, this.second); 
    }

    public static void main(String[] args) {
        Time6 time = new Time6(11, 59, 59.9); 
        String s = time.toString();
        System.out.println("time.toString()="+time); 
        printTime(time); 
    }

}
